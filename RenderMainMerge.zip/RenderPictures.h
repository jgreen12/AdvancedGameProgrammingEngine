// Headers
#include <SFML\Window.hpp>
#include <SFML\Graphics.hpp>
#include <iostream>
#include <GL/glew.h>
#include <GLFW/glfw3.h>
#include <stdlib.h>
#include <stdio.h>
#define GLEW_STATIC
#include <glm/fwd.hpp>
#include <glm/glm.hpp>
#include <glm/gtc/type_ptr.hpp>
#include <glm/gtx/rotate_vector.hpp>
#include <glut/GL/glut.h>
#include <SFML/OpenGL.hpp>
#include <string>
#include <iostream>
#include <Windows.h>
#include <gl\GL.h>
#include <gl\GLU.h>

#ifndef RENDERPICTURES_H
#define RENDERPICTURES_H

class RenderPictures
{
	// For all pictures/textures single input
	struct pictures
	{
		char pictureList[50][100]; // 1 or many picturess in a group
		GLfloat NxyCoord[2];			// Top right box coordinate; Negative x, Positive y from origin point coordinates
		GLfloat xyCoord[2];			// Top left box coordinate; Positive x, Positive y from origin point coordinates
		GLfloat xNyCoord[2];			// Bottom left box coordinate; Positive x, Negative y from origin point coordinates
		GLfloat NxNyCoord[2];			// Bottom right box coordinate; Negative x, Negative y from origin point coordinates
		GLfloat pictureNum;			// How many pictures are in the group
	};

	private:
		pictures gamePictures[50];
		int pictureCount = 0;
		int picArrays;
		int picActiveArray = 0;
		sf::Image images[50];
		int imageCount = 0;
		char fileNames[50][100];

		// Check if gamePictures member is filled or not
		int filled[500];

		void RenderPictures::setFilled()
		{
			for (int i = 0; i < 500; i++)
				filled[i] = 0;
		}

	public:
		RenderPictures();

		void setPictures(char picture[], int origin, GLfloat pictureNum);

		/* Set pictures for each part of the gamePictures object, whether they be 1 picture or many for animation
		file name, x origin coordinate, y origin coordinate, stretch along x axis,, stretch along y axis, number of pictures in group*/
		void setPictures(char picture[], GLfloat xCoord, GLfloat yCoord, GLfloat sxCoord, GLfloat syCoord, GLfloat pictureNum);

		void setAllPictures(GLfloat vertices[][28]);

		// To set up image Load In
		void setImageLoad(char name[]);

		~RenderPictures();
};
#endif