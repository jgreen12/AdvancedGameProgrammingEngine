// Headers
#include <SFML\Window.hpp>
#include <SFML\Graphics.hpp>
#include <iostream>
#include <GL/glew.h>
#include <GLFW/glfw3.h>

#include <stdlib.h>
#include <stdio.h>

#include <string.h>

#define GLEW_STATIC
#include <glm/fwd.hpp>
#include <glm/glm.hpp>
#include <glm/gtc/type_ptr.hpp>
#include <glm/gtx/rotate_vector.hpp>
#include <glut/GL/glut.h>
#include <SFML/OpenGL.hpp>
#include <string>
#include <iostream>
#include <Windows.h>
#include <gl\GL.h>
#include <gl\GLU.h>

using namespace std;

#ifndef RENDERPICTURES_H
#define RENDERPICTURES_H

class RenderPictures
{
	// For all pictures/textures single input
	struct pictures
	{
		string pictureList[50]; // 1 or many picturess in a group
		GLfloat NxyCoord[2];			// Top right box coordinate; Negative x, Positive y from origin point coordinates
		GLfloat xyCoord[2];			// Top left box coordinate; Positive x, Positive y from origin point coordinates
		GLfloat xNyCoord[2];			// Bottom left box coordinate; Positive x, Negative y from origin point coordinates
		GLfloat NxNyCoord[2];			// Bottom right box coordinate; Negative x, Negative y from origin point coordinates
		GLfloat pictureNum;			// How many pictures are in the group
	};

	private:
		pictures gamePictures[50];
		int pictureCount = 0;
		int picArrays;
		int picActiveArray = 0;

		sf::Image images[50];

		int imageCount = 0;

		string fileNames[50];

		// Check if gamePictures member is filled or not
		int filled[50];
		GLfloat vertices[28];
		GLuint shaderProgram;
		GLuint fragmentShader;
		GLuint vertexShader;
		GLuint ebo;
		GLuint vbo;
		GLuint vao;


		void RenderPictures::setFilled()
		{
			for (int i = 0; i < 50; i++)
				filled[i] = 0;
		}


		// Shader sources
		const GLchar* vertexSource =
			"#version 400\n"
			"in vec2 position;"
			"in vec3 color;"
			"in vec2 texcoord;"
			"out vec3 Color;"
			"out vec2 Texcoord;"
			"void main() {"
			"   Color = color;"
			"   Texcoord = texcoord;"
			"   gl_Position = vec4(position, 1.0, 1.0);"
			"}";

		const GLchar* fragmentSource =
			"#version 400\n"
			"in vec3 Color;"
			"in vec2 Texcoord;"
			"out vec4 outColor;"
			"uniform sampler2D teximagePNG;"
			"void main() {"
			"   outColor = texture(teximagePNG, Texcoord);"
			"}";

	public:
		RenderPictures();

		void setImageLoad(string name);


		/* Set pictures for each part of the gamePictures object, whether they be 1 picture or many for animation
		file name, x origin coordinate, y origin coordinate, stretch along x axis,, stretch along y axis, number of pictures in group*/
		// Set Defaults at (0,0) worldspace origin as single square
		void setPictures(string picture, int origin, GLfloat pictureNum);
		
		// Set userdefined object origin and set stretch values
		void setPictures(string picture, GLfloat xCoord, GLfloat yCoord, GLfloat sxCoord, GLfloat syCoord, GLfloat pictureNum);

		// Draw Image
		void showPicture(int i);

		// Render Image
		void init();
		
		// Loop to set all pictures in world, rendering them.
		void renderAllPictures();

		~RenderPictures();
};
#endif