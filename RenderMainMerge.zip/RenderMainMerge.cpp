// Headers
#include <SFML\Window.hpp>
#include <SFML\Graphics.hpp>
#include <iostream>
#include <GL/glew.h>
#include <GLFW/glfw3.h>

#include <stdlib.h>
#include <stdio.h>

#define GLEW_STATIC
#include <glm/fwd.hpp>
#include <glm/glm.hpp>
#include <glm/gtc/type_ptr.hpp>
#include <glm/gtx/rotate_vector.hpp>
#include <glut/GL/glut.h>
#include <SFML/OpenGL.hpp>
#include <string>
#include <iostream>
#include <Windows.h>
#include <gl\GL.h>
#include <gl\GLU.h>

using namespace std;
#include "RenderPictures.h"


sf::Window window(sf::VideoMode(900, 700, 32), "Renderer", sf::Style::Titlebar | sf::Style::Default);


void ManageWindow()
{
	while (window.isOpen())
	{
		// Blue Background
		glClearColor(0.0f, 0.0f, 1.0f, 1.0f);
		glClear(GL_COLOR_BUFFER_BIT);

		// Draw a rectangle from the 2 triangles using 6 vertices
		glDrawElements(GL_TRIANGLES, 6, GL_UNSIGNED_INT, 0);

		sf::Event windowEvent;
		while (window.pollEvent(windowEvent))
		{
			switch (windowEvent.type)
			{
			case sf::Event::Closed:
				window.close();
				break;
			}
		}

		// Swap buffers
		window.display();
	}
}

int main()
{
	RenderPictures pictures;
	
	pictures.setPictures("w.png", 1, 1);
	pictures.setPictures("Smiley.bmp", 0, 0, 2, 2, 1);

	pictures.renderAllPictures();

	// Draw everything and window
	ManageWindow();
	
	pictures.~RenderPictures();
	return 0;
}
