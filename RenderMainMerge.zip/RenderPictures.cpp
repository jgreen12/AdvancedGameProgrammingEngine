// Headers
#include "RenderPictures.h"

RenderPictures::RenderPictures()
{
}

void RenderPictures::setPictures(char picture[], int origin, GLfloat pictureNum)
{
	// Set amount of pictures
	if (pictureNum > 1)
	{
		picArrays = pictureNum;
		picActiveArray++;
	}
	else
	{
		picArrays = 0;
		picActiveArray = 0;
	}

	// Find picture number in group
	int absolute = abs(pictureNum - picArrays);
	if (pictureNum == 1)
		absolute = 0;

	// Set the file names into the char 2D array for multiple pictures in one gamePictures object
	for (int i = 0; i < sizeof(picture); i++)
	{
		gamePictures[pictureCount].pictureList[absolute][i] = picture[i];
	}

	// Set coordinates for each single picture group in gamePictures object in a box
	// Top left corner of box
	gamePictures[pictureCount].NxyCoord[0] = -0.5;
	gamePictures[pictureCount].NxyCoord[1] = 0.5;
	// Top right corner of box
	gamePictures[pictureCount].xyCoord[0] = 0.5;
	gamePictures[pictureCount].xyCoord[1] = 0.5;
	// Bottom left corner of box
	gamePictures[pictureCount].xNyCoord[0] = 0.5;
	gamePictures[pictureCount].xNyCoord[1] = -0.5;
	// Bottom right corner of box
	gamePictures[pictureCount].NxNyCoord[0] = -0.5;
	gamePictures[pictureCount].NxNyCoord[1] = -0.5;

	// Move to the next gamePictures 2D array group
	if (picActiveArray == 0)
	{
		filled[pictureCount] = 1;
		pictureCount++;
	}
}

/* Set pictures for each part of the gamePictures object, whether they be 1 picture or many for animation
file name, x origin coordinate, y origin coordinate, stretch along x axis,, stretch along y axis, number of pictures in group*/
void RenderPictures::setPictures(char picture[], GLfloat xCoord, GLfloat yCoord, GLfloat sxCoord, GLfloat syCoord, GLfloat pictureNum)
{
	// Set amount of pictures
	if (pictureNum > 1)
	{
		picArrays = pictureNum;
		picActiveArray++;
	}
	else
	{
		picArrays = 0;
		picActiveArray = 0;
	}

	// Find picture number in group
	int absolute = abs(pictureNum - picArrays);
	if (pictureNum == 1)
		absolute = 0;

	// Set the file names into the char 2D array for multiple pictures in one gamePictures object
	for (int i = 0; i < sizeof(picture); i++)
	{
		gamePictures[pictureCount].pictureList[absolute][i] = picture[i];
	}

	// Set coordinates for each single picture group in gamePictures object in a box
	// Top left corner of box
	gamePictures[pictureCount].NxyCoord[0] = xCoord - sxCoord;
	gamePictures[pictureCount].NxyCoord[1] = yCoord + syCoord;
	// Top right corner of box
	gamePictures[pictureCount].xyCoord[0] = xCoord + sxCoord;
	gamePictures[pictureCount].xyCoord[1] = yCoord + syCoord;
	// Bottom left corner of box
	gamePictures[pictureCount].xNyCoord[0] = xCoord + sxCoord;
	gamePictures[pictureCount].xNyCoord[1] = yCoord - syCoord;
	// Bottom right corner of box
	gamePictures[pictureCount].NxNyCoord[0] = xCoord - sxCoord;
	gamePictures[pictureCount].NxNyCoord[1] = yCoord - syCoord;

	// Move to the next gamePictures 2D array group
	if (picActiveArray == 0)
	{
		filled[pictureCount] = 1;
		pictureCount++;
	}
}

// Render all images in boxes
void RenderPictures::setAllPictures(GLfloat vertices[][28])
{
	setPictures(fileNames[pictureCount], 1, 1);

	// Set Texture Data
	glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, images[pictureCount].getSize().x, images[pictureCount].getSize().y, 0, GL_RGBA, GL_UNSIGNED_BYTE, images[pictureCount].getPixelsPtr());

	// Draw Texture
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);

	for (int i = 0; i < 500; i++)
	{
		for (int j = 0; j < 28; j++)
		{
			switch (j)
			{
				// Set box coordinates
				case 0:		vertices[i][j] = gamePictures[0].NxyCoord[0];
							break;
				case 1:		vertices[i][j] = gamePictures[0].NxyCoord[1];
							break;
				case 7:		vertices[i][j] = gamePictures[0].xyCoord[0];
							break;
				case 8:		vertices[i][j] = gamePictures[0].xyCoord[1];
							break;
				case 14:	vertices[i][j] = gamePictures[0].xNyCoord[0];
							break;
				case 15:	vertices[i][j] = gamePictures[0].xNyCoord[1];
							break;
				case 21:	vertices[i][j] = gamePictures[0].NxNyCoord[0];
							break;
				case 22:	vertices[i][j] = gamePictures[0].NxNyCoord[1];
							break;

				// Set original box colors and fill texture size in box
				case 2:
				case 10:
				case 12:
				case 18:
				case 19:
				case 20:
				case 23:
				case 24:
				case 25:
				case 27:	vertices[i][j] = 1.0;
							break;
				case 3:
				case 4:
				case 5:
				case 6:
				case 9:
				case 11:
				case 16:
				case 17:
				case 26:	vertices[i][j] = 0.0;
							break;
			}
		}

		if (filled[i] == 0)
			break;
	}
}

// Load in all images to be used
void RenderPictures::setImageLoad(char name[])
{
	for (int i = 0; i < sizeof(name); i++)
	{
		fileNames[imageCount][i] = name[i];
	}
	// Load Image
	images[imageCount].loadFromFile(name);
	imageCount++;
}

RenderPictures::~RenderPictures()
{}
