// Headers
#include "RenderPictures.h"

RenderPictures::RenderPictures()
{
}

void RenderPictures::setPictures(string picture, int origin, GLfloat pictureNum)
{
	fileNames[imageCount] = picture;

	// Load Image
	images[imageCount].loadFromFile(fileNames[imageCount]);
	imageCount++;

	// Set amount of pictures
	if (pictureNum > 1)
	{
		picArrays = pictureNum;
		picActiveArray++;
	}
	else
	{
		picArrays = 0;
		picActiveArray = 0;
	}

	// Find picture number in group
	int absolute = abs(pictureNum - picArrays);
	if (pictureNum == 1)
		absolute = 0;

	// Set the file names into the string array for multiple pictures in one gamePictures object
	gamePictures[pictureCount].pictureList[absolute] = picture;
	

	// Set coordinates for each single picture group in gamePictures object in a box
	// Top left corner of box
	gamePictures[pictureCount].NxyCoord[0] = -0.5;
	gamePictures[pictureCount].NxyCoord[1] = 0.5;
	// Top right corner of box
	gamePictures[pictureCount].xyCoord[0] = 0.5;
	gamePictures[pictureCount].xyCoord[1] = 0.5;
	// Bottom left corner of box
	gamePictures[pictureCount].xNyCoord[0] = 0.5;
	gamePictures[pictureCount].xNyCoord[1] = -0.5;
	// Bottom right corner of box
	gamePictures[pictureCount].NxNyCoord[0] = -0.5;
	gamePictures[pictureCount].NxNyCoord[1] = -0.5;

	// Move to the next gamePictures 2D array group
	if (picActiveArray == 0)
	{
		filled[pictureCount] = 1;
		pictureCount++;
	}
}

/* Set pictures for each part of the gamePictures object, whether they be 1 picture or many for animation
file name, x origin coordinate, y origin coordinate, stretch along x axis,, stretch along y axis, number of pictures in group*/
void RenderPictures::setPictures(string picture, GLfloat xCoord, GLfloat yCoord, GLfloat sxCoord, GLfloat syCoord, GLfloat pictureNum)
{
	fileNames[imageCount] = picture;

	// Load Image
	images[imageCount].loadFromFile(fileNames[imageCount]);
	imageCount++;

	// Set amount of pictures
	if (pictureNum > 1)
	{
		picArrays = pictureNum;
		picActiveArray++;
	}
	else
	{
		picArrays = 0;
		picActiveArray = 0;
	}

	// Find picture number in group
	int absolute = abs(pictureNum - picArrays);
	if (pictureNum == 1)
		absolute = 0;

	// Set the file names into the string array for multiple pictures in one gamePictures object
	gamePictures[pictureCount].pictureList[absolute] = picture;


	// Set coordinates for each single picture group in gamePictures object in a box
	// Top left corner of box
	gamePictures[pictureCount].NxyCoord[0] = xCoord - sxCoord;
	gamePictures[pictureCount].NxyCoord[1] = yCoord + syCoord;
	// Top right corner of box
	gamePictures[pictureCount].xyCoord[0] = xCoord + sxCoord;
	gamePictures[pictureCount].xyCoord[1] = yCoord + syCoord;
	// Bottom left corner of box
	gamePictures[pictureCount].xNyCoord[0] = xCoord + sxCoord;
	gamePictures[pictureCount].xNyCoord[1] = yCoord - syCoord;
	// Bottom right corner of box
	gamePictures[pictureCount].NxNyCoord[0] = xCoord - sxCoord;
	gamePictures[pictureCount].NxNyCoord[1] = yCoord - syCoord;

	// Move to the next gamePictures 2D array group
	if (picActiveArray == 0)
	{
		filled[pictureCount] = 1;
		pictureCount++;
	}
}

// Render all images in boxes
void RenderPictures::showPicture()
{
	// Set Texture Data
	glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, images[0].getSize().x, images[0].getSize().y, 0, GL_RGBA, GL_UNSIGNED_BYTE, images[0].getPixelsPtr());

	// Draw Texture
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);

		for (int j = 0; j < 28; j++)
		{
			switch (j)
			{
				// Set box coordinates
				case 0:		vertices[j] = gamePictures[0].NxyCoord[0];
							break;
				case 1:		vertices[j] = gamePictures[0].NxyCoord[1];
							break;
				case 7:		vertices[j] = gamePictures[0].xyCoord[0];
							break;
				case 8:		vertices[j] = gamePictures[0].xyCoord[1];
							break;
				case 14:	vertices[j] = gamePictures[0].xNyCoord[0];
							break;
				case 15:	vertices[j] = gamePictures[0].xNyCoord[1];
							break;
				case 21:	vertices[j] = gamePictures[0].NxNyCoord[0];
							break;
				case 22:	vertices[j] = gamePictures[0].NxNyCoord[1];
							break;

				// Set original box colors and fill texture size in box
				case 2:
				case 10:
				case 12:
				case 18:
				case 19:
				case 20:
				case 23:
				case 24:
				case 25:
				case 27:	vertices[j] = 1.0;
							break;
				case 3:
				case 4:
				case 5:
				case 6:
				case 9:
				case 11:
				case 16:
				case 17:
				case 26:	vertices[j] = 0.0;
							break;
			}
	}
}


void RenderPictures::init()
{
	// Initialize GLEW
	glewExperimental = GL_TRUE;
	glewInit();

	// Create Vertex Array Object

	glGenVertexArrays(1, &vao);
	glBindVertexArray(vao);

	// Create a Vertex Buffer Object and copy the vertex data to it

	glGenBuffers(1, &vbo);

	glBindBuffer(GL_ARRAY_BUFFER, vbo);
	glBufferData(GL_ARRAY_BUFFER, sizeof(vertices), vertices, GL_STATIC_DRAW);

	// Create an element array

	glGenBuffers(1, &ebo);

	// Do Not Touch!!! Keeps it in rectangle format
	GLuint elements[] = {
		0, 1, 2,
		2, 3, 0
	};

	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, ebo);
	glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(elements), elements, GL_STATIC_DRAW);

	// Create and compile the vertex shader
	vertexShader = glCreateShader(GL_VERTEX_SHADER);
	glShaderSource(vertexShader, 1, &vertexSource, NULL);
	glCompileShader(vertexShader);

	// Create and compile the fragment shader
	fragmentShader = glCreateShader(GL_FRAGMENT_SHADER);
	glShaderSource(fragmentShader, 1, &fragmentSource, NULL);
	glCompileShader(fragmentShader);

	// Link the vertex and fragment shader into a shader program
	shaderProgram = glCreateProgram();
	glAttachShader(shaderProgram, vertexShader);
	glAttachShader(shaderProgram, fragmentShader);
	glBindFragDataLocation(shaderProgram, 0, "outColor");
	glLinkProgram(shaderProgram);
	glUseProgram(shaderProgram);

	// Specify the layout of the vertex data
	GLint posAttrib = glGetAttribLocation(shaderProgram, "position");
	glEnableVertexAttribArray(posAttrib);
	glVertexAttribPointer(posAttrib, 2, GL_FLOAT, GL_FALSE, 7 * sizeof(GLfloat), 0);

	GLint colAttrib = glGetAttribLocation(shaderProgram, "color");
	glEnableVertexAttribArray(colAttrib);
	glVertexAttribPointer(colAttrib, 3, GL_FLOAT, GL_FALSE, 7 * sizeof(GLfloat), (void*)(2 * sizeof(GLfloat)));

	GLint texAttrib = glGetAttribLocation(shaderProgram, "texcoord");
	glEnableVertexAttribArray(texAttrib);
	glVertexAttribPointer(texAttrib, 2, GL_FLOAT, GL_FALSE, 7 * sizeof(GLfloat), (void*)(5 * sizeof(GLfloat)));
}


// Loop to render each game object picture list
void RenderPictures::renderAllPictures()
{
	for (int i = 0; i < 50; i++)
	{
		if (filled[i] == 0)
			break;

		showPicture();
		init();
		cout << "here" << i << "\n";
	}
}

RenderPictures::~RenderPictures()
{
	glDeleteProgram(shaderProgram);
	glDeleteShader(fragmentShader);
	glDeleteShader(vertexShader);

	glDeleteBuffers(1, &ebo);
	glDeleteBuffers(1, &vbo);

	glDeleteVertexArrays(1, &vao);
}
