/********************************************
Author: Noah Pena
Space.cpp
CPP file for header file world.h for creating a world space.
********************************************/
#include "Space.h"

Space::Space(void)
{
	//this->id = dSimpleSpaceCreate(this->id);

	//this->space = new dHashSpace();



	this->space = new dSimpleSpace();
}

Space::~Space(void)
{
	delete space;
	//dSpaceDestroy(this->id);
}

dSpaceID Space::getSpaceID(void)
{
	//return this->id;
	//dSpaceID dafuq;

	//dafuq = this->space->getSpace();
	return this->space->id();
	//return dafuq;
}