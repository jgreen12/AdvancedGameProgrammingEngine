/********************************************
Author: Charles Miller
shader.cpp
CPP file for header file  shader.h to create shaders, set 
uniform variable values from either 1 variable or up to 4. 
Also to enable and disable the shaders.
********************************************/
#include "shader.h"

namespace prototype 
{
	namespace graphics 
	{
		Shader::Shader(const char* vertPath, const char* fragPath) 
			: m_VertPath(vertPath), m_FragPath(fragPath) 
			{
				m_ShaderID = load();
			}

		Shader::~Shader() 
		{
			glDeleteProgram(m_ShaderID);
		}

		GLuint Shader::load()
		{
			GLuint program = glCreateProgram();
			GLuint vertex = glCreateShader(GL_VERTEX_SHADER);
			GLuint fragment = glCreateShader(GL_FRAGMENT_SHADER);

			std::string vertSourceString = FileUtils::read_file(m_VertPath);
			std::string fragSourceString = FileUtils::read_file(m_FragPath);

			const char* vertSource = vertSourceString.c_str();
			const char* fragSource = fragSourceString.c_str();

			// Creates and compiles the vertex shader
			glShaderSource(fragment, 1, &fragSource, NULL);
			glCompileShader(fragment);

			// Status Check
			GLint result;

			// Checks the status of the vertex shader and returns it as result
			glGetShaderiv(vertex, GL_COMPILE_STATUS, &result);

			/* If vertex shader is not compiled, then gets the vertex shader, 
			shows its information, and an error message before ending program */
			if (result == GL_FALSE) 
			{
				GLint length;
				glGetShaderiv(vertex, GL_INFO_LOG_LENGTH, &length);
				std::vector<char> error(length);
				glGetShaderInfoLog(vertex, length, &length, &error[0]);
				std::cout << &error[0] << std::endl;
				glDeleteShader(vertex);
				return 0;
			}

			// Creates and compiles the fragment shader
			glShaderSource(fragment, 1, &fragSource, NULL);
			glCompileShader(fragment);

			// Checks the status of the fragment shader and returns it as result
			glGetShaderiv(fragment, GL_COMPILE_STATUS, &result);

			/* If fragment shader is not compiled, then gets the fragment shader, 
			shows its information, and an error message before ending program */
			if (fragment == GL_FALSE)
			{
				GLint length;
				glGetShaderiv(fragment, GL_INFO_LOG_LENGTH, &length);
				std::vector<char> error(length);
				glGetShaderInfoLog(fragment, length, &length, &error[0]);
				std::cout << &error[0] << std::endl;
				glDeleteShader(fragment);
				return 0;
			}

			glAttachShader(program, vertex);
			glAttachShader(program, fragment);

			glLinkProgram(program);
			glValidateProgram(program);

			glDeleteShader(vertex);
			glDeleteShader(fragment);

			return program;
		}

		GLint Shader::getUniformLocation(const GLchar* name) 
		{
			return glGetUniformLocation(m_ShaderID, name);
		}

		/* Sets the value of an uniform variable (or array) [float, int, unsigned int, bool,
		etc] with the location of the uniform variable (or array) and the float value to 
		assign to it */
		void Shader::setUniform1f(const GLchar* name, float value) 
		{
			glUniform1f(getUniformLocation(name), value);
		}

		/* Sets the value of an uniform variable (or array) [float, int, unsigned int, bool,
		etc] with the location of the uniform variable (or array) and the int value to 
		assign to it */
		void Shader::setUniform1i(const GLchar* name, int value) 
		{
			glUniform1i(getUniformLocation(name), value);
		}

		/* Sets the value of an uniform variable (or array) [vec2] with the location of 
		the uniform variable (or array) and the float value to assign to it */
		void Shader::setUniform2f(const GLchar* name, const maths::vec2& vector) 
		{
			glUniform2f(getUniformLocation(name), vector.x, vector.y);
		}

		/* Sets the value of an uniform variable (or array) [vec3] with the location of 
		the uniform variable (or array) and the float value to assign to it */		
		void Shader::setUniform3f(const GLchar* name, const maths::vec3& vector)
		 {
			glUniform3f(getUniformLocation(name), vector.x, vector.y, vector.z);
		}

		/* Sets the value of an uniform variable (or array) [vec2] with the location of 
		the uniform variable (or array) and the float value to assign to it */
		void Shader::setUniform4f(const GLchar* name, const maths::vec4& vector) 
		{
			glUniform4f(getUniformLocation(name), vector.x, vector.y, vector.z, vector.w);
		}

		// Modify a matrix (or array of matrices) [4x4] of uniform variables with floats
		void Shader::setUniformMat4(const GLchar* name, const maths::mat4& matrix)
		 {
			glUniformMatrix4fv(getUniformLocation(name), 1, GL_FALSE, matrix.elements);
		}

		void Shader::enable() const
		{
			glUseProgram(m_ShaderID);
		}

		void Shader::disable() const 
		{
			glUseProgram(0);
		}
	}
}