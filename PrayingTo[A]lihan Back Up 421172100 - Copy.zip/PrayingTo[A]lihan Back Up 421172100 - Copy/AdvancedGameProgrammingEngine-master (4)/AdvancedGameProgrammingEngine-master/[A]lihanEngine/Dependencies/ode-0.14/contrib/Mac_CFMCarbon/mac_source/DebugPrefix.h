#ifndef prefix_h
#define prefix_h

#include "CommonPrefix.h"

#ifdef dNODEBUG
#undef dNODEBUG
#endif

#endif // prefix_h